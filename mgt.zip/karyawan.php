<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Data Karyawan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Data Karyawan</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <a href="index.php?page=karyawan-tambah" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
          <br><br>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">List Data Karyawan</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>NO</th>
                    <th>NAMA KARYAWAN</th>
                    <th>EMAIL</th>
                    <th>TGL LAHIR</th>
                    <th>DEPARTEMEN</th>
                    <th>JABATAN</th>
                    <th>STATUS</th>
                    <th>PHOTO</th>
                    <th>PERINTAH</th>
                  </tr>
                </thead>
                <tbody>

                  <?php
                    $no = 1;
                    $query_karyawan = mysqli_query($con,"
                    SELECT a.nama_lengkap,a.email,a.tgl_lahir, b.nama_departemen, c.nama_jabatan, a.status, a.id_karyawan,a.photo FROM tb_karyawan a, tb_departemen b, tb_jabatan c WHERE a.id_departemen = b.id_departemen AND a.id_jabatan = c.id_jabatan ORDER BY a.id_karyawan DESC");
                    while($data_karyawan = mysqli_fetch_array($query_karyawan)) {
                      echo '
                        <tr>
                          <td>'.$no++.'</td>
                          <td>'.$data_karyawan['nama_lengkap'].'</td>
                          <td>'.$data_karyawan['email'].'</td>
                          <td>'.date('d/m/Y',strtotime($data_karyawan['tgl_lahir'])).'</td>
                          <td>'.$data_karyawan['nama_departemen'].'</td>
                          <td>'.$data_karyawan['nama_jabatan'].'</td>
                          <td>'.$data_karyawan['status'].'</td>
                          <td><img src="upload/'.$data_karyawan['photo'].'" width="50" height="50"> </td>
                          <td>
                            <a href="index.php?page=karyawan-edit&id='.$data_karyawan['id_karyawan'].'" class="btn btn-success btn-sm"><i class="fa fa-edit"></i> Edit</a>
                            &nbsp;&nbsp;
                            <a href="hapus-karyawan.php?id='.$data_karyawan['id_karyawan'].'" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> Hapus</a>
                          </td>';

                    }
                  ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->