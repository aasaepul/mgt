<?php
  
  include "koneksi.php";

  if(!empty($_GET['id'])) {

      $id = $_GET['id'];

      $query_hapus = mysqli_query($con, "DELETE FROM tb_karyawan WHERE id_karyawan = '$id'");
      if($query_hapus) {
        echo '<script>alert("Data Berhasil Dihapus");window.location.href="index.php?page=karyawan"</script>';
      } else {
        echo '<script>alert("Data Gagal Dihapus");window.location.href="index.php?page=karyawan"</script>';
      }
  }
  
?>