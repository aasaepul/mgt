
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Data Notice</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Data Notice</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <a href="index.php?page=notice-tambah" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah Data</a>
          <br><br>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">List Data Notice</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>NO</th>
                    <th>SUBJEK</th>
                    <th>KETERANGAN</th>
                    <th>TGL INPUT</th>
                    <th>NAMA KARYAWAN</th>
                    <th>JABATAN</th>
                    <th>STATUS</th>
                    <th>PERINTAH</th>
                  </tr>
                </thead>
                <tbody>

                  <?php
                    $no = 1;
                    $query_notice = mysqli_query($con,"SELECT a.*, b.*, c.* FROM tb_notice a, tb_karyawan b, tb_jabatan c WHERE a.id_karyawan = b.id_karyawan AND b.id_jabatan = c.id_jabatan ORDER BY a.id_notice DESC");
                    while($data_notice = mysqli_fetch_array($query_notice)) {
                      echo '
                        <tr>
                          <td>'.$no++.'</td>
                          <td>'.$data_notice['subjek'].'</td>
                          <td>'.$data_notice['keterangan'].'</td>
                          <td>'.$data_notice['tgl_input'].'</td>
                          <td>'.$data_notice['nama_lengkap'].'</td>
                          <td>'.$data_notice['nama_jabatan'].'</td>
                          <td>'.$data_notice['status_notice'].'</td>
                          <td>
                            <a href="index.php?page=notice-edit&id='.$data_notice['id_notice'].'" class="btn btn-success btn-sm"><i class="fa fa-edit"></i> Edit</a>
                            &nbsp;&nbsp;
                            <a href="hapus-notice.php?id='.$data_notice['id_notice'].'" class="btn btn-danger btn-sm"><i class="fa fa-trash-o"></i> Hapus</a>
                          </td>';
                    }
                  ?>
                </tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->