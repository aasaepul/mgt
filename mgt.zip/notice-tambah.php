<?php
  
  if(isset($_POST['simpan'])) {

      $subjek        = mysqli_real_escape_string($con, $_POST['subjek']);
      $keterangan    = mysqli_real_escape_string($con, $_POST['keterangan']);
      $karyawan      = mysqli_real_escape_string($con, $_POST['karyawan']);

      $query            = mysqli_query($con, "INSERT INTO tb_notice VALUES (null,'$subjek','$keterangan',now(),'$karyawan','Pending')");

      if($query) {
          echo '<script>alert("Data berhasil tersimpan");</script>';
      } else {
          echo '<script>alert("Data gagal tersimpan");</script>';
      }

  }
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Tambah Notice</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah Notice</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <a href="index.php?page=notice" class="btn btn-primary"><i class="fa fa-chevron-left"></i> Kembali</a>
          <br><br>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">List Data Notice</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form action="" method="POST">
                <div class="card-body">
                  <div class="form-group">
                    <label>Subjek</label>
                    <input type="text" name="subjek" class="form-control" required>
                  </div>
                  <div class="form-group">
                    <label>Keterangan</label>
                    <input type="text" name="keterangan" class="form-control" required>
                  </div>
                  <div class="form-group">
                    <label>Nama Karyawan</label>
                    <select name="karyawan" class="form-control">
                      <option>-- Pilih Karyawan --</option>
                      <?php
                        $query_karyawan = mysqli_query($con, "SELECT * FROM tb_karyawan ORDER BY nama_lengkap ASC");
                        while($data_karyawan = mysqli_fetch_array($query_karyawan)) {
                            echo '<option value="'.$data_karyawan['id_karyawan'].'">'.$data_karyawan['nama_lengkap'].'</option>';
                          }
                      ?>
                    </select>
                  </div>
                </div>
                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->