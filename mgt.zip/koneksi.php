<?php

	$host = "localhost";
	$user = "root";
	$pass = "";
	$db   = "db_mgt";

	$con  = mysqli_connect($host,$user,$pass,$db);

	session_start();
	error_reporting(0);
?>