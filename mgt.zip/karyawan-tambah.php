<?php
  
  if(isset($_POST['simpan'])) {

      $nik              = mysqli_real_escape_string($con, $_POST['nik']);
      $nama_karyawan    = mysqli_real_escape_string($con, $_POST['nama_karyawan']);
      $email            = mysqli_real_escape_string($con, $_POST['email']);
      $telepon          = mysqli_real_escape_string($con, $_POST['telepon']);
      $tgl_lahir        = mysqli_real_escape_string($con, $_POST['tgl_lahir']);
      $nama_departemen  = mysqli_real_escape_string($con, $_POST['departemen']);
      $nama_jabatan     = mysqli_real_escape_string($con, $_POST['jabatan']);
      $status           = mysqli_real_escape_string($con, $_POST['status']);
      $username         = mysqli_real_escape_string($con, $_POST['username']);
      $password         = mysqli_real_escape_string($con, md5($_POST['password']));

      $photo_name     = mysqli_real_escape_string($con,$_FILES['photo']['name']);
      $tmp_name       = $_FILES['photo']['tmp_name'];
      $type_name      = mysqli_real_escape_string($con,$_FILES['photo']['type']);
      $size_name      = mysqli_real_escape_string($con,$_FILES['photo']['size']);

      $folder         = 'upload/';

      $file_type      = array('jpg','JPG','jpeg','JPEG','png','PNG');

      $max_size       = 5000000;

      $file_name      = str_replace(" ", "_", $photo_name);

      $explode        = explode(".", $file_name);

      $extensi        = $explode[count($explode)-1];

      if(!in_array($extensi, $file_type)) {
        echo "<script>alert('Tipe File Tidak Mendukung');</script>";
      } else if ($size_name > $max_size) {
        echo "<script>alert('Ukuran Gambar Terlalu Besar');</script>";
      } else {

        if($photo_name == '') {

          $query            = mysqli_query($con, "INSERT INTO tb_karyawan VALUES (null,'$nik','$nama_karyawan','$email','$telepon','$tgl_lahir','$nama_departemen','$nama_jabatan','$status','$username','$password')");
        } else 
        
        {
          $filename_photo = $file_name.'.'.$extensi;
          move_uploaded_file($tmp_name, $folder.$filename_photo);

          $query            = mysqli_query($con, "INSERT INTO tb_karyawan VALUES (null,'$nik','$nama_karyawan','$email','$telepon','$tgl_lahir','$nama_departemen','$nama_jabatan','$status','$username','$password','$filename_photo')");
        }

      }

      if($query) {
          echo '<script>alert("Data berhasil tersimpan");</script>';
      } else {
          echo '<script>alert("Data gagal tersimpan");</script>';
      }
  }
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1>Tambah Karyawan</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Tambah Karyawan</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-12">
          <a href="index.php?page=karyawan" class="btn btn-primary"><i class="fa fa-chevron-left"></i> Kembali</a>
          <br><br>
          <div class="card">
            <div class="card-header">
              <h3 class="card-title">List Data Karyawan</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <form action="" method="POST" enctype="multipart/form-data">
                <div class="card-body">
                  <div class="form-group">
                    <label>NIK</label>
                    <input type="text" name="nik" class="form-control" required>
                  </div>
                  <div class="form-group">
                    <label>Nama Karyawan</label>
                    <input type="text" name="nama_karyawan" class="form-control">
                  </div>
                  <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control">
                  </div>
                  <div class="form-group">
                    <label>Telepon</label>
                    <input type="text" name="telepon" class="form-control">
                  </div>
                  <div class="form-group">
                    <label>Tgl Lahir</label>
                    <input type="text" name="tgl_lahir" id="datepicker" class="form-control" autocomplete="off">
                  </div>
                  <div class="form-group">
                    <label>Departemen</label>
                    <select name="departemen" class="form-control">
                      <option>-- Pilih Departemen --</option>
                      <?php
                        $query_departemen = mysqli_query($con, "SELECT * FROM tb_departemen ORDER BY nama_departemen ASC");
                        while($data_departemen = mysqli_fetch_array($query_departemen)) {
                            echo '<option value="'.$data_departemen['id_departemen'].'">'.$data_departemen['nama_departemen'].'</option>';
                          }
                      ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Jabatan</label>
                    <select name="jabatan" class="form-control">
                      <option>-- Pilih Jabatan --</option>
                      <?php
                        $query_jabatan = mysqli_query($con, "SELECT * FROM tb_jabatan ORDER BY nama_jabatan ASC");
                        while($data_jabatan = mysqli_fetch_array($query_jabatan)) {
                            echo '<option value="'.$data_jabatan['id_jabatan'].'">'.$data_jabatan['nama_jabatan'].'</option>';
                          }
                      ?>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                      <option value="Aktif">Aktif</option>
                      <option value="Non Aktif">Non Aktif</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control">
                  </div>

                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control">
                  </div>
                  <div class="form-group">
                    <label>Photo</label>
                    <input type="file" name="photo" class="form-control">
                  </div>
                </div>

                <div class="card-footer">
                  <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->